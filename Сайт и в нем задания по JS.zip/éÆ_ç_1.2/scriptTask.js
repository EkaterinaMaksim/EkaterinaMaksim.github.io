function Day(){
    document.querySelector("#window").classList.toggle("window");
    document.querySelector("#window").classList.toggle("window_night");
 
    document.getElementsByClassName("nextp")[0].classList.toggle("button_day");
    document.getElementsByClassName("nextp")[0].classList.toggle("button_night");
    document.getElementsByClassName("nextp")[1].classList.toggle("button_day");
    document.getElementsByClassName("nextp")[1].classList.toggle("button_night");
    document.getElementsByClassName("sent")[0].classList.toggle("button_day");
    document.getElementsByClassName("sent")[0].classList.toggle("button_night");
    document.getElementsByClassName("check_it")[0].classList.toggle("button_day");
    document.getElementsByClassName("check_it")[0].classList.toggle("button_night");
    document.getElementsByClassName("batton_block")[0].classList.toggle("button_day");
    document.getElementsByClassName("batton_block")[0].classList.toggle("button_night");
    document.getElementsByClassName("batton_block")[1].classList.toggle("button_day");
    document.getElementsByClassName("batton_block")[1].classList.toggle("button_night");
 
    var elems = document.getElementsByClassName("menu_text");
    for(var i = 0; i < elems.length; i++)
    {
       elems[i].classList.toggle("menu_text_day");
       elems[i].classList.toggle("menu_text_night");
    }
    
    document.getElementById("Light_side").setAttribute("style","display:none");
    document.getElementById("Dark_side").setAttribute("style","display:block");
 
    
    document.querySelector("#HTML").classList.toggle("ClassHTML_day");
    document.querySelector("#HTML").classList.toggle("ClassHTML_night");
 
    document.querySelector("#menu_id").classList.toggle("menu");
    document.querySelector("#menu_id").classList.toggle("menu_night");
 
 
    document.querySelector("#article_id").classList.toggle("index2");
    document.querySelector("#article_id").classList.toggle("index2_night");
    document.querySelector("#article_id").querySelector("h1").classList.toggle("index2h1");
    document.querySelector("#article_id").querySelector("h1").classList.toggle("index2h1_night");
    document.querySelector("#article_id").querySelector("h3").classList.toggle("index2h2");
    document.querySelector("#article_id").querySelector("h3").classList.toggle("index2h2_night");
 
    
    
 
   
 
    
 
    document.getElementById("a1a").classList.toggle("block1comp");
    document.getElementById("a1a").classList.toggle("block1comp_night");
 }
 function Night(){
 
    document.querySelector("#window").classList.toggle("window_night");
    document.querySelector("#window").classList.toggle("window");
 
    document.getElementsByClassName("nextp")[0].classList.toggle("button_night");
    document.getElementsByClassName("nextp")[0].classList.toggle("button_day");
    document.getElementsByClassName("nextp")[1].classList.toggle("button_night");
    document.getElementsByClassName("nextp")[1].classList.toggle("button_day");
    document.getElementsByClassName("sent")[0].classList.toggle("button_night");
    document.getElementsByClassName("sent")[0].classList.toggle("button_day");
    document.getElementsByClassName("check_it")[0].classList.toggle("button_night");
    document.getElementsByClassName("check_it")[0].classList.toggle("button_day");
    document.getElementsByClassName("batton_block")[0].classList.toggle("button_night");
    document.getElementsByClassName("batton_block")[0].classList.toggle("button_day");
    document.getElementsByClassName("batton_block")[1].classList.toggle("button_night");
    document.getElementsByClassName("batton_block")[1].classList.toggle("button_day");
 
    var elems = document.getElementsByClassName("menu_text");
    for(var i = 0; i < elems.length; i++)
    {
       elems[i].classList.toggle("menu_text_night");
       elems[i].classList.toggle("menu_text_day");
    }
 
    document.getElementById("Dark_side").setAttribute("style","display:none");
    document.getElementById("Light_side").setAttribute("style","display:block");
 
    document.querySelector("#HTML").classList.toggle("ClassHTML_day");
    document.querySelector("#HTML").classList.toggle("ClassHTML_night");
 
    document.querySelector("#menu_id").classList.toggle("menu_night");
    document.querySelector("#menu_id").classList.toggle("menu");
 
    document.querySelector("#article_id").classList.toggle("index2_night");
    document.querySelector("#article_id").classList.toggle("index2");
    document.querySelector("#article_id").querySelector("h1").classList.toggle("index2h1_night");
    document.querySelector("#article_id").querySelector("h1").classList.toggle("index2h1");
    document.querySelector("#article_id").querySelector("h3").classList.toggle("index2h2_night");
    document.querySelector("#article_id").querySelector("h3").classList.toggle("index2h2");
 
 
    
 
    
 
   
    
 
    document.getElementById("a1a").classList.toggle("block1comp_night");
    document.getElementById("a1a").classList.toggle("block1comp");
   
 }