let elem = document.querySelector('#elem'); 
let elem2 = document.querySelector('#elem2'); 
let parent = document.querySelector('#parent'); 
    
    parent.addEventListener('dragover',function(event){ 
    event.preventDefault(); 
    console.log("over");
    });
    
    
    elem.addEventListener('dragstart',function(){
    event.dataTransfer.setData("Text", event.target.id);
    });
    
    elem2.addEventListener('dragstart',function(){
    event.dataTransfer.setData("Text", event.target.id);
    });
    
    
    // при отпускании элемента (внутри корзины) вызываем функцию (увеличения кол-ва товаров)
    // для элемента (товара) по его айди
    parent.addEventListener('drop',function(event){
    plusFunction(event.dataTransfer.getData("Text"));
    });
    
    //объект элементов корзины
let cart = [
    {
    id: "elem",
    name: "Пюрешка",
    count: 0,
    },
    
    {
    id: "elem2",
    name: "Дошик",
    count: 0,
    }
    ];
    
    
    // увеличение кол-ва товаров
    const plusFunction = id => {
    if (id == "elem")
    {
    cart[0].count++;
    }
    else if (id == "elem2")
    {
    cart[1].count++;
    }
    renderCart(); // рисует заново корзину
    }
    
    const renderCart = () => {
    console.log(cart[0].count);
    console.log(cart[1].count);
    if(cart[0].count!=0){
        document.getElementById("cart-div1").innerHTML = (`Пюрешка: ${cart[0].count}`);
    }
    if(cart[1].count!=0){
        document.getElementById("cart-div2").innerHTML = (`Дошик: ${cart[1].count}`);
    }
    }