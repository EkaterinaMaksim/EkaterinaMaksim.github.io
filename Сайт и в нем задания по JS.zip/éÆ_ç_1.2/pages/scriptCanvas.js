function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
    }


let button = document.querySelector("#canvasButton");


function canvasDraw() {
    let number = Number(document.querySelector('#count').value);
    let art = document.querySelector("#canvas");

    let stylish = art.getContext("2d");
    stylish.clearRect(0, 0, art.width, art.height);
    stylish.fillStyle = "rgb(187, 153, 226)";
    let k = 0;
    let i = 0;

    while(i!=number){
        stylish.fillRect(k, 300, 30, getRandomInt(-150, -200));
        i++;
        k+=33;
        }
    }

button.addEventListener("click", canvasDraw);