var foto = document.getElementById("foto");
var buttonF = document.getElementById("buttonF");
var buttonS = document.getElementById("buttonS");


function Ffirst(){

    foto.setAttribute("style", "display:block");
    buttonF.setAttribute("style","display:none");
    buttonS.setAttribute("style","display:block");
    localStorage.setItem("blockFoto",foto.style.display);
    localStorage.setItem("buttonF",buttonF.style.display);
    localStorage.setItem("buttonS",buttonS.style.display);
    
}
function Ssecond(){

    foto.setAttribute("style","display:none");
    buttonF.setAttribute("style","display:block");
    buttonS.setAttribute("style","display:none");
    localStorage.setItem("blockFoto",foto.style.display);
    localStorage.setItem("buttonF",buttonF.style.display);
    localStorage.setItem("buttonS",buttonS.style.display);
}

foto.style.display = localStorage.getItem("blockFoto");
buttonF.style.display = localStorage.getItem("buttonF");
buttonS.style.display = localStorage.getItem("buttonS");
